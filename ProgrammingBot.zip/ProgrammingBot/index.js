const Discord = require ('discord.js');
const bot = new Discord.Client();

bot.on('message',  (message) => {
    if(message.content == 'youtube') {
        message.channel.sendMessage('Our YouTube channel is ProgrammingCats if you did not know');
    }
});

bot.on('message',  (message) => {
    if(message.content == 'programmingbot') {
        message.channel.sendMessage('What?');
    }
});

bot.on('message',  (message) => {
    if(message.content == 'commands') {
        message.channel.sendMessage('Commands are "programmingbot, youtube, commands, dylm"');
    }
});

bot.on('message',  (message) => {
    if(message.content == 'dylm') {
        message.channel.sendMessage('Do you love me? I love being a friend of yours');
    }
});

bot.login('NTUyNDUxNTQ2ODk0MzAzMjM0.D2BrPw.3XoaLbX6v9r5njfEfRTsap8aefI');